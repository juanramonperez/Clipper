<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<?php if($op == 'view') :// el clip se esta viendo (no esta siendo editado)?>
<div class="main-template eclip-02 view">
  <div class="main-template-inner">
    <div class="main-top">
      <div class="main-top-inner">
        <div class="zone-01"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 1, $node->nid) : ''; ?></div>
        <div class="zone-02"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 2, $node->nid) : ''; ?></div>
        <div class="zone-03"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 3, $node->nid) : ''; ?></div>
      </div>      
    </div>
    <div class="main-middle">
      <div class="main-middle-inner">
        <div class="zone-04"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 4, $node->nid) : ''; ?></div>
        <div class="zone-05"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 5, $node->nid) : ''; ?></div>
        <div class="zone-06"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 6, $node->nid) : ''; ?></div>
      </div>        
    </div>
    <div class="main-bottom">
      <div class="main-bottom-inner">
        <div class="zone-07"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 7, $node->nid) : ''; ?></div>
        <div class="zone-08"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 8, $node->nid) : ''; ?></div>
        <div class="zone-09"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 9, $node->nid) : ''; ?></div>
        <div class="zone-10"><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 10, $node->nid) : ''; ?></div>
      </div>        
    </div>      
  </div>
</div>
<?php else: ?>
<div class="main-template eclip-02">
  <div class="main-template-inner">
    <div class="main-top">
      <div class="main-top-inner">
        <div class="clipper-placeholder zone-01"><span class="zone-label">Zone 01</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 1, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-02"><span class="zone-label">Zone 02</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 2, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-03"><span class="zone-label">Zone 03</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 3, $node->nid) : ''; ?></div>
      </div>      
    </div>
    <div class="main-middle">
      <div class="main-middle-inner">
        <div class="clipper-placeholder zone-04"><span class="zone-label">Zone 04</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 4, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-05"><span class="zone-label">Zone 05</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 5, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-06"><span class="zone-label">Zone 06</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 6, $node->nid) : ''; ?></div>
      </div>        
    </div>
    <div class="main-bottom">
      <div class="main-bottom-inner">
        <div class="clipper-placeholder zone-07"><span class="zone-label">Zone 07</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 7, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-08"><span class="zone-label">Zone 08</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 8, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-09"><span class="zone-label">Zone 09</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 9, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-10"><span class="zone-label">Zone 10</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 10, $node->nid) : ''; ?></div>
      </div>        
    </div>      
  </div>
</div>
<?php endif; ?>