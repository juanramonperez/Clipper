<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<?php if($op == 'view') :// el clip se esta viendo (no esta siendo editado)?>
<div class="main-template eclip-01 view">
  <div class="main-template-inner">
    <div class="main-left">
      <div class="main-left-inner">
        <div class="zone-1"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 1, $node->nid) : ''; ?></div>
        <div class="zone-2"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 2, $node->nid) : ''; ?></div>
        <div class="zone-3"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 3, $node->nid) : ''; ?></div>
      </div>      
    </div>
    <div class="main-center">
      <div class="main-center-inner">
        <div class="zone-4"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 4, $node->nid) : ''; ?></div>
        <div class="zone-5"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 5, $node->nid) : ''; ?></div>
        <div class="zone-6"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 6, $node->nid) : ''; ?></div>
      </div>        
    </div>
    <div class="main-right">
      <div class="main-right-inner">
        <div class="zone-7"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 7, $node->nid) : ''; ?></div>
        <div class="zone-8"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 8, $node->nid) : ''; ?></div>
        <div class="zone-9"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 9, $node->nid) : ''; ?></div>
        <div class="zone-10"><?php isset($node->nid) ? print views_embed_view('front_get_categories', 'default', 10, $node->nid) : ''; ?></div>
      </div>        
    </div>      
  </div>
</div>
<?php else: ?>
<div class="main-template eclip-01">
  <div class="main-template-inner">
    <div class="main-left">
      <div class="main-left-inner">
        <div class="clipper-placeholder zone-1"><span class="zone-label">Zone 01</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 1, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-2"><span class="zone-label">Zone 02</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 2, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-3"><span class="zone-label">Zone 03</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 3, $node->nid) : ''; ?></div>
      </div>      
    </div>
    <div class="main-center">
      <div class="main-center-inner">
        <div class="clipper-placeholder zone-4"><span class="zone-label">Zone 04</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 4, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-5"><span class="zone-label">Zone 05</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 5, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-6"><span class="zone-label">Zone 06</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 6, $node->nid) : ''; ?></div>
      </div>        
    </div>
    <div class="main-right">
      <div class="main-right-inner">
        <div class="clipper-placeholder zone-7"><span class="zone-label">Zone 07</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 7, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-8"><span class="zone-label">Zone 08</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 8, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-9"><span class="zone-label">Zone 09</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 9, $node->nid) : ''; ?></div>
        <div class="clipper-placeholder zone-10"><span class="zone-label">Zone 10</span><?php isset($node->nid) ? print views_embed_view('helper_get_categories', 'default', 10, $node->nid) : ''; ?></div>
      </div>        
    </div>      
  </div>
</div>
<?php endif; ?>
