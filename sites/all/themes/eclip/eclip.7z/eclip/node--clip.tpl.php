<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?>"<?php print $attributes; ?>>
  <?php print theme($template, array('op' => 'view', 'node' => $node)); ?>
</div>